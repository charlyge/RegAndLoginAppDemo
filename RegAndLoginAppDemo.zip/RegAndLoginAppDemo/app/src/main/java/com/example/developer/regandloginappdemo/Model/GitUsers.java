package com.example.developer.regandloginappdemo.Model;

import java.util.List;

public class GitUsers {
    private int total_count;
    private String incomplete_results;
    private List<Items> items;

    public GitUsers(int total_count, String incomplete_results, List<Items> items) {
        this.total_count = total_count;
        this.incomplete_results = incomplete_results;
        this.items = items;
    }

    public List<Items> getItems() {
        return items;
    }

    public String getIncomplete_results() {
        return incomplete_results;
    }

    public GitUsers(int total_count, String incomplete_results) {
        this.total_count = total_count;
        this.incomplete_results = incomplete_results;
    }

    public int getTotal_count() {
        return total_count;
    }


}
