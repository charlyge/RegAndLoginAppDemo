package com.example.developer.regandloginappdemo;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.developer.regandloginappdemo.Model.Users;

import java.util.Date;

public class SessionHandler {
    private static final String PREF_NAME = "UserSession";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_EXPIRES = "expires";
    private static final String KEY_FULL_NAME = "full_name";
    private static final String KEY_EMPTY = "";

    private Context mContext;
    private SharedPreferences.Editor mEditor;
    private SharedPreferences mPreferences;


    public void loginUser(String userName, String fullName){
    mEditor.putString(KEY_USERNAME,userName);
    mEditor.putString(KEY_FULL_NAME,fullName);

        Date date = new Date();
        long millis = date.getTime() + (7 * 24 * 60 * 60 * 1000);
        mEditor.putLong(KEY_EXPIRES,millis);
        mEditor.commit();

    }

    public boolean isLogedIn() {
    Date currentDate = new Date();
    long millis = mPreferences.getLong(KEY_EXPIRES,0);
    if(millis == 0){
        return false;
    }
        Date expiryDate = new Date(millis);
    return  currentDate.before(expiryDate);

    }

    public Users getUsersDetails(){
        if(isLogedIn()){
            return null;
        }

        String userName = mPreferences.getString(KEY_USERNAME,KEY_EMPTY);
        String fullName = mPreferences.getString(KEY_FULL_NAME,KEY_EMPTY);
        Date sessionExpiryDate = new Date(mPreferences.getLong(KEY_EXPIRES,0));

        return new Users(userName,fullName,sessionExpiryDate);

    }


    public void logOut(){
        mEditor.clear();
        mEditor.commit();
    }

}
