package com.example.developer.regandloginappdemo.Model;

import java.util.Date;

public class Users {
    private String username;
    private String fullName;
    private Date sessionExpiryDate;

    public Users( String username,String fullName,Date sessionExpiryDate){
        this.username = username;
         this.fullName= fullName;
        this.sessionExpiryDate = sessionExpiryDate;

    }

    public String getUsername() {
        return username;
    }

    public Date getSessionExpiryDate() {
        return sessionExpiryDate;
    }

    public String getFullName() {
        return fullName;
    }
}
