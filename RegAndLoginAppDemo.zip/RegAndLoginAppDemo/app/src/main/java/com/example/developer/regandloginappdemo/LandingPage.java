package com.example.developer.regandloginappdemo;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.developer.regandloginappdemo.NotificationUtils.makeNotification;
import com.example.developer.regandloginappdemo.Services.MyService;

import static com.example.developer.regandloginappdemo.Constants.Constants.SERVICE_ACTION;

public class LandingPage extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_landing_page);

}

    public void gotoDemoVolleyActivity(View view) {

        //Start Service with Scheduler WorkManager
        Intent intent = new Intent(this,DemoVolleyActivity.class);
        startActivity(intent);
    }


}
