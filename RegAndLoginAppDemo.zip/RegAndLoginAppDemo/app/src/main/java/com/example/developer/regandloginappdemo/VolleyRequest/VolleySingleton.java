package com.example.developer.regandloginappdemo.VolleyRequest;

import android.content.Context;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;

public class VolleySingleton {
    private static VolleySingleton mInstance;
    private  RequestQueue requestQueue;
    private  static Context _context;

    private VolleySingleton(Context context) {
        this._context = context;
        requestQueue =getRequestQueue();

    }

    public synchronized static VolleySingleton getmInstance(Context context) {
        if (mInstance == null){
            mInstance = new VolleySingleton(context);
        }
        return mInstance;
    }

    public  RequestQueue getRequestQueue() {
        if(requestQueue== null){
            requestQueue = Volley.newRequestQueue(_context.getApplicationContext());
        }
        return requestQueue;
    }

    public  <T> void addToRequestQueue(Request<T> request){
        getRequestQueue().add(request);

    }
}
