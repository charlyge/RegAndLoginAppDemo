package com.example.developer.regandloginappdemo;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.developer.regandloginappdemo.GitUsersAdapter.GitUsersAdapter;
import com.example.developer.regandloginappdemo.Model.GitUsers;
import com.example.developer.regandloginappdemo.Model.Items;
import com.example.developer.regandloginappdemo.NotificationUtils.makeNotification;
import com.example.developer.regandloginappdemo.Services.MyService;
import com.example.developer.regandloginappdemo.VolleyRequest.VolleySingleton;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.List;

import static com.example.developer.regandloginappdemo.Constants.Constants.JSON_EXTRA;
import static com.example.developer.regandloginappdemo.Constants.Constants.MY_PREFERENCE;
import static com.example.developer.regandloginappdemo.Constants.Constants.users_url;
import static com.example.developer.regandloginappdemo.NotificationUtils.makeNotification.makenotification;

public class DemoVolleyActivity extends AppCompatActivity {

    GitUsersAdapter gitUsersAdapter;
    private  List<Items> itemsList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo_volley);
        fetchUsers();
        RecyclerView recyclerView = findViewById(R.id.recycler);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        gitUsersAdapter = new GitUsersAdapter();
        recyclerView.setLayoutManager(linearLayoutManager);
         recyclerView.setHasFixedSize(true);
         recyclerView.setAdapter(gitUsersAdapter);


    }

    public void fetchUsers(){
        RequestQueue requestQueue = VolleySingleton.getmInstance(this.getApplicationContext()).getRequestQueue();
        StringRequest stringRequest = new StringRequest(Request.Method.GET, users_url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.i("Response", response);
                SharedPreferences.Editor editor = getSharedPreferences(MY_PREFERENCE,MODE_PRIVATE).edit();
                editor.putString(JSON_EXTRA,response);
                editor.apply();

                MyService.startServiceAction(DemoVolleyActivity.this);

            GsonBuilder gsonBuilder = new GsonBuilder();
                Gson gson = gsonBuilder.create();
                GitUsers users = gson.fromJson(response,GitUsers.class);
                Toast.makeText(DemoVolleyActivity.this,"Users is " + users.toString(),Toast.LENGTH_LONG).show();
                itemsList = users.getItems();
                gitUsersAdapter.setItemsList(itemsList);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            Log.i("Error Ocuured",error.getLocalizedMessage());
            }
        });
      VolleySingleton.getmInstance(this).addToRequestQueue(stringRequest);
    }


}
