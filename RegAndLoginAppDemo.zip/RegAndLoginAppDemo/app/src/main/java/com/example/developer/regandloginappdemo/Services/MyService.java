package com.example.developer.regandloginappdemo.Services;

import android.app.IntentService;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;

import com.example.developer.regandloginappdemo.Model.GitUsers;
import com.example.developer.regandloginappdemo.Model.Items;
import com.example.developer.regandloginappdemo.Model.Users;
import com.example.developer.regandloginappdemo.NewAppWidget;
import com.example.developer.regandloginappdemo.NotificationUtils.makeNotification;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.List;

import static com.example.developer.regandloginappdemo.Constants.Constants.JSON_EXTRA;
import static com.example.developer.regandloginappdemo.Constants.Constants.MY_PREFERENCE;
import static com.example.developer.regandloginappdemo.Constants.Constants.SERVICE_ACTION;

public class MyService extends IntentService{


    public MyService() {
        super("MyService");
    }

    public static void startServiceAction(Context context){
        Intent intent = new Intent(context,MyService.class);
        intent.setAction(SERVICE_ACTION);
        context.startService(intent);
    }

    @Override
    protected void onHandleIntent(Intent intent) {
       String action = intent.getAction();
        if (action != null && action.equals(SERVICE_ACTION)) {
            Log.i("ServiceStarted",action);
            handleActionOpenUsers();

        }

    }

    private void handleActionOpenUsers() {
        String usersLogin = null;

        StringBuilder stringBuilder = new StringBuilder();
        SharedPreferences sharedPreferences = getSharedPreferences(MY_PREFERENCE,MODE_PRIVATE);
        String users = sharedPreferences.getString(JSON_EXTRA,"");
        Log.i("ServiceStarted",users);
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        GitUsers gitUsers = gson.fromJson(users,GitUsers.class);
            List<Items> usersList = gitUsers.getItems();
            for (Items items : usersList) {
                String userName = items.getLogin();
                stringBuilder.append(userName).append("\n");
            }
              usersLogin = stringBuilder.toString();
        Log.i("ServiceStarted",usersLogin);
        AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(this);
            int[] widgetIds = appWidgetManager.getAppWidgetIds(new ComponentName(this,NewAppWidget.class));
        Log.i("widgetId", String.valueOf(widgetIds.length));
        NewAppWidget.updateWidget(this,usersLogin,appWidgetManager,widgetIds);

    }
}
