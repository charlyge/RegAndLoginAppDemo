package com.example.developer.regandloginappdemo.Constants;

public class Constants {
    public static final String SERVICE_ACTION = "service action";
    public static final String MY_PREFERENCE = "MyPreference";
    public static final String JSON_EXTRA = "JSON_EXTRA";
    public static String users_url = "https://api.github.com/search/users?q=%22%22+location:lagos+language:java";

}
